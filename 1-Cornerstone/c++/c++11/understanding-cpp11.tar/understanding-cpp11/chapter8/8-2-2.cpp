__declspec(align(32)) struct Struct32 {
    int i;
    double d;
};
