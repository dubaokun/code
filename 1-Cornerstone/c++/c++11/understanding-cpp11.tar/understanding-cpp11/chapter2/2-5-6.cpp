int positive(const int n) {
    static_assert(n > 0, "value must >0");
}
