#include <initializer_list>

auto x = 1;
auto x1(1);

auto y {1};     // 使用初始化列表的auto

auto z = new auto(1);   // 可以用于new
