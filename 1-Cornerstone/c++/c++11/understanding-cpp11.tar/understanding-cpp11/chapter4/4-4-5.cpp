auto (*fp)() -> decltype(1);
