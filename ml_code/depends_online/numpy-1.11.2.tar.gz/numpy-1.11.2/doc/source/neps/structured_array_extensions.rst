.. include:: ../../neps/structured_array_extensions.rst
